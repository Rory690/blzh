# Bubble-the-better-google.
Bubble is a search engine i developed for a school project, the project was about how would you make a better google.

NOTE: Bubble uses googles open sorce programable search engine tools and i do not take full credit for makeing this as it is run on open sorce code.
